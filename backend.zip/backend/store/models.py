from django.db import models

# Create your models here.
from django.db import models
from django.template.defaultfilters import slugify
from django.contrib.auth.models import User
from django.urls import reverse

from django.conf import settings
from django.db.models import Q
from products.models import Product
User = settings.AUTH_USER_MODEL

class StoreQuerySet(models.QuerySet):
    def is_public(self):
        return self.filter(public=True)

    def search(self, query, user=None):
        lookup = Q(title__icontains=query) | Q(content__icontains=query)
        qs = self.is_public().filter(lookup)
        if user is not None:
            qs2 = self.filter(user=user).filter(lookup)
            qs = (qs | qs2).distinct()
        return qs

class StoreManager(models.Manager):
    def get_queryset(self, *args,**kwargs):
        return StoreQuerySet(self.model, using=self._db)

    def search(self, query, user=None):
        return self.get_queryset().search(query, user=user)

class Store(models.Model):
    user = models.ForeignKey(User, default=1, null=True, on_delete=models.SET_NULL)
    store_name = models.CharField(max_length=255)
    store_location = models.CharField(unique=True, max_length=255)
    store_address = models.TextField()
    store_phoneno= models.CharField(max_length=12)
    store_website= models.CharField(max_length=50, null=True)
    store_youtube= models.CharField(max_length=100)
    store_category= models.CharField(max_length=100)
    store_is_ecommerce= models.CharField(max_length=100)
    picture = models.ImageField(upload_to='store/%Y/%m/',max_length=255,null=True)

    objects = StoreManager()

    def get_absolute_url(self):
        return f"/api/Store/{self.pk}/"

    @property
    def endpoint(self):
        return self.get_absolute_url()

    @property
    def path(self):
        return f"/Store/{self.pk}/"

class CampaignQuerySet(models.QuerySet):
    def is_public(self):
        return self.filter(public=True)

    def search(self, query, store=None):
        lookup = Q(title__icontains=query) | Q(content__icontains=query)
        qs = self.is_public().filter(lookup)
        if store is not None:
            qs2 = self.filter(store=store).filter(lookup)
            qs = (qs | qs2).distinct()
        return qs

class CampaignManager(models.Manager):
    def get_queryset(self, *args,**kwargs):
        return CampaignQuerySet(self.model, using=self._db)

    def search(self, query, store=None):
        return self.get_queryset().search(query, store=store)

class Campaign(models.Model):
    store = models.ForeignKey(Store, default=1, null=True, on_delete=models.SET_NULL)
    campaign_name = models.CharField(max_length=255)
    campaign_link = models.CharField(unique=True, max_length=255)
    campaign_offers = models.TextField()
    campaign_description = models.CharField(max_length=12)


    objects = CampaignManager()

    def get_absolute_url(self):
        return f"/api/Campaign/{self.pk}/"

    @property
    def endpoint(self):
        return self.get_absolute_url()

    @property
    def path(self):
        return f"/Campaign/{self.pk}/"


class ProductQuerySet(models.QuerySet):
    def is_public(self):
        return self.filter(public=True)

    def search(self, query, user=None):
        lookup = Q(title__icontains=query) | Q(content__icontains=query)
        qs = self.is_public().filter(lookup)
        if user is not None:
            qs2 = self.filter(user=user).filter(lookup)
            qs = (qs | qs2).distinct()
        return qs

class ProductManager(models.Manager):
    def get_queryset(self, *args,**kwargs):
        return ProductQuerySet(self.model, using=self._db)

    def search(self, query, user=None):
        return self.get_queryset().search(query, user=user)

# class Productss(models.Model):
#     user = models.ForeignKey(User, default=1, null=True, on_delete=models.SET_NULL)
#     product_name = models.CharField(max_length=255)
#     product_uom = models.CharField(unique=True, max_length=255)
#     product_size = models.CharField(unique=True, max_length=255)
#     product_color = models.CharField(unique=True, max_length=255)
#     product_brand_details = models.TextField()
#     product_warrenty = models.TextField()
#     product_price = models.DecimalField(max_digits=32, decimal_places=2)
#     product_discount = models.TextField()
#     product_description = models.CharField(max_length=12)
#
#     objects = ProductManager()
#
#     def get_absolute_url(self):
#         return f"/api/Campaign/{self.pk}/"
#
#     @property
#     def endpoint(self):
#         return self.get_absolute_url()
#
#     @property
#     def path(self):
#         return f"/Campaign/{self.pk}/"





class Storeproduct(models.Model):
    store = models.ForeignKey(Store, default=1, null=True, on_delete=models.SET_NULL)
    product = models.ForeignKey(Product, default=1, null=True, on_delete=models.SET_NULL)




