from django.shortcuts import render
from rest_framework.decorators import authentication_classes, permission_classes
from .serializers import StoreSerializer,CampaignSerializer
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from rest_framework import generics, mixins
from rest_framework.decorators import api_view
from rest_framework.response import Response
# from django.http import Http404
from django.shortcuts import get_object_or_404
from api.mixins import (
    StaffEditorPermissionMixin,
    UserQuerySetMixin)

from .models import Store,Campaign

# Create your views here.
# @permission_classes([])
# @authentication_classes([])
# class StoreCreate(APIView):
#
#     def post(self, request):
#         serializer = StoreSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data, status=102)
#         return Response(serializer.errors, status=100)


# @permission_classes([])
# @authentication_classes([])
class StoreCreate(
    UserQuerySetMixin,

    generics.ListCreateAPIView):
    queryset = Store.objects.all()
    serializer_class = StoreSerializer

    def perform_create(self, serializer):
        # serializer.save(user=self.request.user)
        # title = serializer.validated_data.get('title')
        # content = serializer.validated_data.get('content') or None
        # if content is None:
        #     content = title
        serializer.save(user=self.request.user)
        # send

store_list_create_view = StoreCreate.as_view()


class StoreDetailAPIView(
    UserQuerySetMixin,

    generics.RetrieveAPIView):
    queryset = Store.objects.all()
    serializer_class = StoreSerializer
    # lookup_field = 'pk' ??

store_detail_view = StoreDetailAPIView.as_view()


class StoreUpdateAPIView(
    UserQuerySetMixin,

    generics.UpdateAPIView):
    queryset = Store.objects.all()
    serializer_class = StoreSerializer
    lookup_field = 'pk'

    def perform_update(self, serializer):
        instance = serializer.save()
        # if not instance.content:
        #     instance.content = instance.title
            ##

store_update_view = StoreUpdateAPIView.as_view()


class StoreDestroyAPIView(
    UserQuerySetMixin,
    StaffEditorPermissionMixin,
    generics.DestroyAPIView):
    queryset = Store.objects.all()
    serializer_class = StoreSerializer
    lookup_field = 'pk'

    def perform_destroy(self, instance):
        # instance
        super().perform_destroy(instance)

store_destroy_view = StoreDestroyAPIView.as_view()



class CampaignCreate(


    generics.ListCreateAPIView):
    queryset = Campaign.objects.all()
    serializer_class = CampaignSerializer

    def perform_create(self, serializer):
        # serializer.save(user=self.request.user)
        # title = serializer.validated_data.get('title')
        # content = serializer.validated_data.get('content') or None
        # if content is None:
        #     content = title
        serializer.save()
        # send

campaign_list_create_view = CampaignCreate.as_view()


class CampaignDetailAPIView(


    generics.RetrieveAPIView):
    queryset = Campaign.objects.all()
    serializer_class = CampaignSerializer
    # lookup_field = 'pk' ??

campaign_detail_view = CampaignDetailAPIView.as_view()


class CampaignUpdateAPIView(
    UserQuerySetMixin,

    generics.UpdateAPIView):
    queryset = Campaign.objects.all()
    serializer_class = CampaignSerializer
    lookup_field = 'pk'

    def perform_update(self, serializer):
        instance = serializer.save()
        # if not instance.content:
        #     instance.content = instance.title
            ##

campaign_update_view = CampaignUpdateAPIView.as_view()


class CampaignDestroyAPIView(
    UserQuerySetMixin,
    StaffEditorPermissionMixin,
    generics.DestroyAPIView):
    queryset = Store.objects.all()
    serializer_class = StoreSerializer
    lookup_field = 'pk'

    def perform_destroy(self, instance):
        # instance
        super().perform_destroy(instance)

Campaign_destroy_view = CampaignDestroyAPIView.as_view()


class ProductCreate(


    generics.ListCreateAPIView):
    queryset = Campaign.objects.all()
    serializer_class = CampaignSerializer

    def perform_create(self, serializer):
        # serializer.save(user=self.request.user)
        # title = serializer.validated_data.get('title')
        # content = serializer.validated_data.get('content') or None
        # if content is None:
        #     content = title
        serializer.save()
        # send

product_list_create_view = ProductCreate.as_view()


from .serializers import StoreSerialiser
from rest_framework import status
class Storeproductcreate(APIView):
    def post(self, request):
        serializer = StoreSerialiser(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"DONE"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)