from django.urls import path

from .views import StoreV2View

# /api/products/
urlpatterns = [
    path('', StoreV2View.as_view(), name='storeV2_view'),
]