from rest_framework import serializers
from .models import StoreV2

class StoreV2Serializer(serializers.ModelSerializer):

    #url = serializers.SerializerMethodField()
    def get_url(self, obj):
        request = self.context.get('request')
        if request is not None:
            host = request.get_host()
            print(host)
            return f"http://{host}{obj.image.url}"
        return obj.image.url
    class Meta:
        model = StoreV2
        fields = ('id', 'image','location')
