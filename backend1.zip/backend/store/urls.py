from django.urls import path

from . import views

# /api/products/


urlpatterns = [
    path('', views.store_list_create_view, name='store-list'),
    path('<int:pk>/update/', views.store_update_view, name='store-edit'),
    path('<int:pk>/delete/', views.store_destroy_view),
    path('<int:pk>/', views.store_detail_view, name='store-detail'),
    path('campaign/', views.campaign_list_create_view, name='campaign-list'),
    path('<int:pk>/update_campaign/', views.campaign_update_view, name='campaign-edit'),
    path('<int:pk>/delete_campaign/', views.Campaign_destroy_view),
    path('campaign/<int:pk>/', views.campaign_detail_view, name='campaign-detail'),
    path('category/', views.category_list_create_view, name='category-list'),
    path('subcategory/', views.subcategory_list_create_view, name='subcategory-list'),
    path('products/', views.products_list_create_view, name='product-list'),

    # path('imagetest', views.Imagvalidated_dataetest.as_view(), name='imagetest'),
    path('product/', views.product_list_create_view, name='product-list'),
    path('storetest/', views.Storeproductcreate.as_view(), name='Storeproduct'),

]

