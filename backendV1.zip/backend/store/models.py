from django.db import models

# Create your models here.
from django.db import models
from django.template.defaultfilters import slugify
from django.contrib.auth.models import User
from django.urls import reverse

from django.conf import settings
from django.db.models import Q
from products.models import Product
User = settings.AUTH_USER_MODEL

class StoreQuerySet(models.QuerySet):
    def is_public(self):
        return self.filter(public=True)

    def search(self, query, user=None):
        lookup = Q(title__icontains=query) | Q(content__icontains=query)
        qs = self.is_public().filter(lookup)
        if user is not None:
            qs2 = self.filter(user=user).filter(lookup)
            qs = (qs | qs2).distinct()
        return qs

class Country(models.Model):
    country_name = models.CharField(max_length=100)

class State(models.Model):
    state_name = models.CharField(max_length=100)

class City(models.Model):
    city_name = models.CharField(max_length=100)

class Address(models.Model):
    street = models.TextField()
    country = models.ForeignKey(Country, default=1,null=True,  on_delete=models.CASCADE)
    state = models.ForeignKey(State, default=1,null=True, on_delete=models.CASCADE)
    city = models.ForeignKey(City, default=1,null=True,  on_delete=models.CASCADE)
class StoreManager(models.Manager):
    def get_queryset(self, *args,**kwargs):
        return StoreQuerySet(self.model, using=self._db)

    def search(self, query, user=None):
        return self.get_queryset().search(query, user=user)

class Store(models.Model):
    user = models.ForeignKey(User, default=1, null=True, on_delete=models.SET_NULL)
    address = models.ForeignKey(Address, null=True,on_delete=models.CASCADE)
    store_name = models.CharField(max_length=255)
    store_about = models.CharField(max_length=255,null=True)
    store_location = models.CharField( max_length=255)
    #store_address = models.TextField()
    store_phoneno = models.CharField(max_length=12)
    store_website = models.CharField(max_length=50, null=True)
    store_youtube = models.CharField(max_length=100 ,null=True)
    store_instagram = models.CharField(max_length=100, null=True)
    store_category = models.CharField(max_length=100)
    store_is_ecommerce = models.CharField(max_length=100)
    store_online_link = models.TextField(null=True)
    picture = models.ImageField(upload_to='store/%Y/%m/',max_length=255,null=True)

    objects = StoreManager()

    def get_absolute_url(self):
        return f"/api/Store/{self.pk}/"

    @property
    def endpoint(self):
        return self.get_absolute_url()

    @property
    def path(self):
        return f"/Store/{self.pk}/"







class CampaignQuerySet(models.QuerySet):
    def is_public(self):
        return self.filter(public=True)

    def search(self, query, store=None):
        lookup = Q(title__icontains=query) | Q(content__icontains=query)
        qs = self.is_public().filter(lookup)
        if store is not None:
            qs2 = self.filter(store=store).filter(lookup)
            qs = (qs | qs2).distinct()
        return qs

class CampaignManager(models.Manager):
    def get_queryset(self, *args,**kwargs):
        return CampaignQuerySet(self.model, using=self._db)

    def search(self, query, store=None):
        return self.get_queryset().search(query, store=store)

class Campaign(models.Model):
    store = models.ForeignKey(Store, default=1, null=True, on_delete=models.SET_NULL)
    campaign_name = models.CharField(max_length=255)
    campaign_link = models.CharField(unique=True, max_length=255)
    campaign_offers = models.TextField()
    campaign_description = models.CharField(max_length=12)


    objects = CampaignManager()

    def get_absolute_url(self):
        return f"/api/Campaign/{self.pk}/"

    @property
    def endpoint(self):
        return self.get_absolute_url()

    @property
    def path(self):
        return f"/Campaign/{self.pk}/"


class ProductQuerySet(models.QuerySet):
    def is_public(self):
        return self.filter(public=True)

    def search(self, query, user=None):
        lookup = Q(title__icontains=query) | Q(content__icontains=query)
        qs = self.is_public().filter(lookup)
        if user is not None:
            qs2 = self.filter(user=user).filter(lookup)
            qs = (qs | qs2).distinct()
        return qs

class ProductManager(models.Manager):
    def get_queryset(self, *args,**kwargs):
        return ProductQuerySet(self.model, using=self._db)

    def search(self, query, user=None):
        return self.get_queryset().search(query, user=user)


# class Productss(models.Model):
#     user = models.ForeignKey(User, default=1, null=True, on_delete=models.SET_NULL)
#     product_name = models.CharField(max_length=255)
#     product_uom = models.CharField(unique=True, max_length=255)
#     product_size = models.CharField(unique=True, max_length=255)
#     product_color = models.CharField(unique=True, max_length=255)
#     product_brand_details = models.TextField()
#     product_warrenty = models.TextField()
#     product_price = models.DecimalField(max_digits=32, decimal_places=2)
#     product_discount = models.TextField()
#     product_description = models.CharField(max_length=12)
#
#     objects = ProductManager()
#
#     def get_absolute_url(self):
#         return f"/api/Campaign/{self.pk}/"
#
#     @property
#     def endpoint(self):
#         return self.get_absolute_url()
#
#     @property
#     def path(self):
#         return f"/Campaign/{self.pk}/"





class Storeproduct(models.Model):
    store = models.ForeignKey(Store, default=1, null=True, on_delete=models.SET_NULL)
    product = models.ForeignKey(Product, default=1, null=True, on_delete=models.SET_NULL)



class CatQuerySet(models.QuerySet):
    def is_public(self):
        return self.filter(public=True)

    def search(self, query, user=None):
        lookup = Q(title__icontains=query) | Q(content__icontains=query)
        qs = self.is_public().filter(lookup)
        if user is not None:
            qs2 = self.filter(user=user).filter(lookup)
            qs = (qs | qs2).distinct()
        return qs
class CategoryManager(models.Manager):
    def get_queryset(self, *args,**kwargs):
        return CatQuerySet(self.model, using=self._db)

    def search(self, query, user=None):
        return self.get_queryset().search(query, user=user)
class Category(models.Model):
    category_name = models.CharField(max_length=255)
    category_imagee = models.ImageField(upload_to='category/%Y/%m/',max_length=255,null=True)
    objects = CategoryManager()

    def get_absolute_url(self):
        return f"/api/category/{self.pk}/"

    @property
    def endpoint(self):
        return self.get_absolute_url()

    @property
    def path(self):
        return f"/category/{self.pk}/"


class SubCatQuerySet(models.QuerySet):
    def is_public(self):
        return self.filter(public=True)

    def search(self, query, user=None):
        lookup = Q(title__icontains=query) | Q(content__icontains=query)
        qs = self.is_public().filter(lookup)
        if user is not None:
            qs2 = self.filter(user=user).filter(lookup)
            qs = (qs | qs2).distinct()
        return qs
class SubCategoryManager(models.Manager):
    def get_queryset(self, *args,**kwargs):
        return SubCatQuerySet(self.model, using=self._db)

    def search(self, query, user=None):
        return self.get_queryset().search(query, user=user)

class Subcategory(models.Model):
    category = models.ForeignKey(Category, default=1, null=True, on_delete=models.SET_NULL)
    subcategory_name = models.CharField(max_length=255)
    objects = SubCategoryManager()



import random
from django.conf import settings
from django.db import models
from django.db.models import Q


TAGS_MODEL_VALUES = ['electronics', 'cars', 'boats', 'movies', 'cameras']

class Products(models.Model):
    # pk
    user = models.ForeignKey(User, default=1, null=True, on_delete=models.SET_NULL)
    title = models.CharField(max_length=120)
    content = models.TextField(blank=True, null=True)
    price = models.DecimalField(max_digits=15, decimal_places=2, default=99.99)
    public = models.BooleanField(default=True)
    category = models.ForeignKey(Category, default=1, null=True, on_delete=models.SET_NULL)
    subcategory = models.ForeignKey(Subcategory, default=1, null=True, on_delete=models.SET_NULL)
    store = models.ForeignKey(Store, default=1, null=True, on_delete=models.SET_NULL)
    image = models.ImageField(upload_to='category/%Y/%m/',max_length=255,null=True)
    promotion_link = models.TextField(blank=True, null=True)
    buy_link = models.TextField(blank=True, null=True)

    objects = ProductManager()

    def get_absolute_url(self):
        return f"/api/products/{self.pk}/"

    @property
    def endpoint(self):
        return self.get_absolute_url()

    @property
    def path(self):
        return f"/products/{self.pk}/"

    @property
    def body(self):
        return self.content

    def is_public(self) -> bool:
        return self.public # True or False

    def get_tags_list(self):
        return [random.choice(TAGS_MODEL_VALUES)]

    @property
    def sale_price(self):
        return "%.2f" %(float(self.price) * 0.8)

    def get_discount(self):
        return "122"


class Storeimage(models.Model):
    store = models.ForeignKey(Store, default=1, null=True, on_delete=models.SET_NULL)
    picture = models.ImageField(upload_to='store_image/%Y/%m/',max_length=255,null=True)

    def get_absolute_url(self):
        return f"/api/Store_image/{self.pk}/"

    @property
    def endpoint(self):
        return self.get_absolute_url()

    @property
    def path(self):
        return f"/Store_image/{self.pk}/"