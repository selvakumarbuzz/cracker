
from rest_framework import serializers
from rest_framework.reverse import reverse


from .models import Store,Campaign,Storeproduct,Address,Category,Subcategory,Products,Storeimage
from products.serializers import ProductSerializer
from products.models import Product


# class StoreSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Store
#         fields = [
#             'store_name',
#             'store_location',
#             'store_address',
#             'store_phoneno'
#         ]

from api.serializers import UserPublicSerializer


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = '__all__'


class StoreSerializer(serializers.ModelSerializer):
    owner = UserPublicSerializer(source='user', read_only=True)

    class Meta:
        model = Store

        fields = [
            'pk',
            'owner',
            'picture',

            'store_name',
            'store_location',
            'store_address',
            'store_phoneno',
            'store_website',
        ]


    def get_my_user_data(self, obj):
        return {
            "username": obj.user.username
        }

    def get_edit_url(self, obj):
        request = self.context.get('request')  # self.request
        if request is None:
            return None
        return reverse("product-edit", kwargs={"pk": obj.pk}, request=request)
        # def get_edit_url(self, obj):
    #     request = self.context.get('request')  # self.request
    #     if request is None:
    #         return None
    #     return reverse("product-edit", kwargs={"pk": obj.pk}, request=request)


class CampaignSerializer(serializers.ModelSerializer):
    store = StoreSerializer

    class Meta:
        model = Campaign

        fields = [
            'pk',
            "store",
            "campaign_name",
            "campaign_link",
            "campaign_offers",
            "campaign_description"
        ]


    # def get_my_user_data(self, obj):
    #     return {
    #         "username": obj.user.username
    #     }
    #
    def get_edit_url(self, obj):
        request = self.context.get('request')  # self.request
        if request is None:
            return None
        return reverse("campaign-edit", kwargs={"pk": obj.pk}, request=request)
        # def get_edit_url(self, obj):
    #     request = self.context.get('request')  # self.request
    #     if request is None:
    #         return None
    #     return reverse("product-edit", kwargs={"pk": obj.pk}, request=request)


class StoreproductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Storeproduct
        fields = "__all__"


class StoreSerialiser(serializers.ModelSerializer):
    #store_product = StoreproductSerializer(many=True)
    address = AddressSerializer()
    owner = UserPublicSerializer(source='user', read_only=True)
    class Meta:
        model = Store

        fields = [
            'pk',
            'owner',
            'store_name',
            'store_location',
            'address',
            'store_phoneno',
            'store_website',

        ]

    # def create(self, validated_data):
    #     store_product_datas = validated_data.pop('store_product')
    #     store = Store.objects.create(**validated_data)
    #     for store_product_data in store_product_datas:
    #         Storeproduct.objects.create(store=store, **store_product_data)
    #     return store


    def create(self, validated_data):
        #store_product_datas = validated_data.pop('store_product')
        store_address_datas = validated_data.pop('address')
        address = Address.objects.create(**store_address_datas)
        # store = Store.objects.create(**store_product_datas)
        # for store_product_data in store_product_datas:
        #     Storeproduct.objects.create(store=store, **store_product_data)

        store = Store.objects.create(

            address=address,**validated_data
        )
        return store

class StoreImage(serializers.ModelSerializer):
    class Meta:
        model = Storeimage
        fields = '__all__'

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'


class SubcategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Subcategory
        fields = '__all__'


class ProductsSerializer(serializers.ModelSerializer):
    owner = UserPublicSerializer(source='user', read_only=True)

    body = serializers.CharField(source='content')

    class Meta:
        model = Products
        fields = [
            'owner',
            'pk',
            'title',
            'body',
            'category',
            'subcategory',
            'price',
            'image',
            'sale_price',
            'public',
            'path',
            'endpoint',
            'store',
        ]

    def get_my_user_data(self, obj):
        return {
            "username": obj.user.username
        }

    def get_edit_url(self, obj):
        request = self.context.get('request')  # self.request
        if request is None:
            return None
        return reverse("product-edit", kwargs={"pk": obj.pk}, request=request)
