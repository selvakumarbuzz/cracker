
from django.conf import settings
from django.utils import timezone
from django.db import models

User = settings.AUTH_USER_MODEL # auth.User

# Create your models here.
class StoreV2(models.Model):
    userid = models.ForeignKey(User,null=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=500,null=True, blank=True)
    location = models.CharField(max_length=100,null=True, blank=True)
    other = models.CharField(max_length=100,null=True, blank=True)
    address = models.CharField(max_length=500,null=True, blank=True)
    youtube = models.CharField(max_length=500,null=True, blank=True)
    insta = models.CharField(max_length=500,null=True, blank=True)
    contact = models.IntegerField(null=True, blank=True)
    site = models.CharField(max_length=500,null=True, blank=True)
    image = models.ImageField(upload_to='uploads/')
    created_at = models.DateTimeField(default=timezone.now, blank=True)
    updated_at = models.DateTimeField(default=timezone.now, blank=True)

    def __str__(self):
        return f"{self.name} - {self.location}"
    



